// NicheMaster 2026 - Configuration
// Edit this file to customize your store

window.NICHEMASTER_CONFIG = {
    // === PAYPAL INTEGRATION ===
    paypal: {
        // Replace this with your real PayPal email / merchant email
        email: "slottzb46@gmail.com",   // <--- UPDATED WITH YOUR EMAIL
        
        // Currency (USD, EUR, GBP etc.)
        currency: "USD",
        
        // Return / cancel URLs (update these to your live domain)
        returnUrl: "https://nichemaster-store.slottzn45.workers.dev/thank-you.html",
        cancelUrl: "https://nichemaster-store.slottzn45.workers.dev/",
        
        // Optional: PayPal button style
        buttonStyle: "paypal"
    },
    
    // Store info
    store: {
        name: "NicheMaster 2026",
        tagline: "Premium ebooks for 2026",
        supportEmail: "support@nichemaster.ai"
    },
    
    // After purchase settings
    downloads: {
        // Where the actual files live
        basePath: "downloads/",
        
        // Show a nice success page with download buttons
        useThankYouPage: true
    }
};

// Helper to build PayPal "Buy Now" link
function buildPayPalLink(item) {
    const cfg = window.NICHEMASTER_CONFIG.paypal;
    
    const params = new URLSearchParams({
        cmd: "_xclick",
        business: cfg.email,
        item_name: item.title,
        amount: item.price,
        currency_code: cfg.currency,
        return: cfg.returnUrl + "?item=" + item.id,
        cancel_return: cfg.cancelUrl,
        no_shipping: "1",
        no_note: "1"
    });
    
    return `https://www.paypal.com/cgi-bin/webscr?${params.toString()}`;
}

// Helper to build PayPal "Add to Cart" (for bundles)
function buildPayPalAddToCartLink(items) {
    // For simplicity we use multiple _xclick or recommend Buy Now for now
    // Advanced: you can use PayPal's cart system
    const cfg = window.NICHEMASTER_CONFIG.paypal;
    
    const total = items.reduce((sum, i) => sum + i.price, 0);
    
    const params = new URLSearchParams({
        cmd: "_xclick",
        business: cfg.email,
        item_name: `NicheMaster Bundle - ${items.length} ebooks`,
        amount: total.toFixed(2),
        currency_code: cfg.currency,
        return: cfg.returnUrl,
        cancel_return: cfg.cancelUrl,
    });
    
    return `https://www.paypal.com/cgi-bin/webscr?${params.toString()}`;
}